08. Aug. 2009
***********************************************************************
*                    Welcome to Premium Reversi 2001                  *
*                                                                     *
* Devloped by: Kristian Sandven, SandSoft                             *
* Email: premrev@graps.net                                            *
* URL: http://www.graps.net/SandSoft/PremRev                          *
*                                                                     *
***********************************************************************

Today I stumbled over the source code for this game that I made over a decade ago. I thought that I would try and compile it and see if I could get it working in a modern OS.
And work it did! This new version has been named "Platinum Edition". 
I have re-enabled the record game feature that was taken out in an earlier release. Unfortunately I was not able to re-enable the spectator mode for the multiplayer since I do not have the time to test this properly. 

This game is now FREEWARE. I hope you enjoy the game!

Whatsnew in Premium Reversi 2001, v1.20 [FINAL]
***********************************************************************
* This version is FREEWARE. No registration required
* Added one new feature: Games can now be saved to file and played back at a later time. 

Whatsnew in Premium Reversi 2001, v1.11 [FINAL]
***********************************************************************
* This version expires 30. May 2005 (Trial only).
* Fixed music bug in credits dialog.

Whatsnew in Premium Reversi 2001, v1.10 [FINAL]
***********************************************************************
* This version expires 31. March 2003 (Trial only)
* Done some minor changes to the AI. Should be a 5-10% increase in performance.
* [DISABLED IN 1.10 FINAL] Spectator mode added. Up to 50 people can watch a multiplayer game! They can also chat with the players and the
  other spectators!
* [DISABLED IN 1.10 FINAL] New tab in the preferences dialog (Server setup). You can setup default settings for your server!


Whatsnew in Premium Reversi 2001, v1.10 [BETA]
***********************************************************************
* You can now place disks by using the keyboard.
* Keyboard is locked to possible moves when "Show possible moves" is enabled.
* SKill level 4, 8 and 9 has been disabled in the shareware version.
* Unlimited number of undo operations! Statistics will not be recorded if you use undo.
* Undo is disabled in the shareware version.
* You will now get a warning if you try to exit the game while hosting a multiplayergame.
* Updated online help.
* Premium Reversi 2001 now works correctly on systems without a soundcard (e.g. Terminal Server Client)

* Chat window is redesigned. 
	+ Online players are displayed to the right
	+ Command history added. Use uparrow and downarrow to see the last 100 commands.

* New commands in the console:
	+ !SRVER - gets the server version
	+ !CLS - clear screen
	+ !HINTS [ON|OFF] - Enables or disables hints.
	+ !SPECTATORS [ON|OFF] - Allow or deny spectators to connect.


	* Added protocol version checking. All clients now recive a Version message from the server.  

* Spectator mode added. Up to 50 people can watch a multiplayer game! They can also chat with the players and the
  other spectators!
* New tab in the preferences dialog (Server setup). You can setup default settings for your server!
	
* New network code: (mainly to add support for spectators)
	* Clients prior to version 1.10 will not function with version 1.10 and above because they
	  don't check the version of the messages.



Whatsnew in Premium Reversi 2001, v1.02a
***********************************************************************
* This version expires 30. April 2002 (Trial only).
* This release fixes a stupid bug that caused a random crash when loading a saved game.
* Current skill-level is now saved on exit.
* When you have defeated a level the game will now ask if you want to try the next level.

Whatsnew in Premium Reversi 2001, v1.02
***********************************************************************
* This version expires 31. March 2002 (Trial only)
* Fixed Windows XP spesific problem: Icon indicating player color in lower right corner was not displayed.
* Premium Reversi has now been tested on Windows XP. 
* Updated the  email addresses that were left out in v1.01
* Now uses NullSoft Install System 
* PremRev.exe now packed with UPX

Whatsnew in Premium Reversi 2001, v1.01
***********************************************************************
* This version expires 31. December 2001 (Trial only)
* Updated online help
* Updated Internet links and email addresses!
* Minor changes in the AI
* Registration dialog can be activated from Help|About

Whatsnew in Premium Reversi 2001, v1.00 FINAL
***********************************************************************
* This version expires 01. March 2001 (Trial only)
* Updated online help
* The gameboard can now be changed. This version includes 10 different boards!!!
* Some bug fixes.

Whatsnew in Premium Reversi 2001, Release Candidate 2
***********************************************************************
* Premium Reversi has now been tested with DirectX 8!
* Removed support for recording games. 
* Added online help
* Fixed ReInstall and Uninstall.
* Game now has SHAREWARE status. The trial period is 21 days. After that time the program must be unlocked with a valid key.  NOTE! RC 2 expire 31.12.2000 and cannot be used after that date.

Whatsnew in Premium Reversi 2001, Release Candidate 1
***********************************************************************
* Added support for recording games. 
* Now using DirectSound for SoundEffects!
* Some new SFX (win/lose).
* Fixed bug in gameloading.
* Fixed random crash at first move.
* Show last move enabled!
* Various fixes in multiplayer.
* Two players can no longer have the same name.
* Added F8 as shortcut to preferences and F11 to chat.
* Added Setup to preferences (ReInstall).
* Added DirectX version check.
* Some enhancements to the AI.
* Time are now displayed for both players.
* Starting a new game now correctly terminates the current game.
* Demos are no longer the same each time.

Whatsnew in Premium Reversi 2001, Beta release 3
***********************************************************************
* Added preferences dialog. Currently only player options. More pages will be added as needed (setup (install/uninstall), game, sound, apperance, general).
* Full multiplayer support through DirectPlay. 
	- Choose Multiplayer|Start multiplayer game...
	- Type your name and Select connection type 
	- You can now either create a new game (you are host) or join a game.
		- Create a game by clicking the create button. Type a gamename and click enter. If the program crashes at this point repeat the previous steps but make sure to uncheck "Use Directplay Protocol".
		- Click start search to view available games. Note: If you are not connected to a network and want to play a 2 player game on your local computer type 127.0.0.1 (loopback) in the ip-field.
		- Select a game and click join.
	- You will now see the New multiplayer game dialog. If you are ready to play checkthe ready checkbox and follow the instructions. 
	- You can chat with other players by selecting chat from the multiplayer menu.
	- Only the host can start a new game. The host also decide what color you are. Use the chatwindow to agree on the settings. Who starts the game is random!
	- You can exit or disconnect a game at any time.

	- The chatwindow can also be used as a commandline. One very useful command is the move command (=). Enter "=A3" without the "s. You will then place a piece at A3 if that is a vaild move. ! is used invoke commands that have no parameters, e.g. !help, !exit. 


Whatsnew in Premium Reversi 2001, Beta release 2 
***********************************************************************
* Win Othello 2001 has now changed name to Premium Reversi 2001
* Game statistics and ranking system added
* Save and Load games added 
* New userinterface
* SFX added (may cause crash, disable sound if game crashes when you click the gameboard)
* Various new options...


Change History
---------------------
* Rewritten AI. Using MINMAX algorithm with alphabeta cutoffs and move ordering.
* Temporary disabled network game. 
* improved Demo-mode. A demo can now be interruped at any time and you can continue playing for the computer. A equal random AI-level (1-9) will be set for the compeeting computers.  
* AI level (difficulty level) can be set at any point during the game
* Enabled statistics
* New outline option. Displays all your possible moves.

---------------------
* Some enhancements to the AI. Moves leaveing the opponent with 1 or 0 moves are given priority.

---------------------
* New and improved AI. I'm now using the MINMAX algorithm.
* Added demo mode, the computer is playing against itself! Level is selected at random.
* You can now set the AI level of the computer opponent. Warning: setting level to anything above 7 is not recommended (it is very slow, up to several minutes on each move!!!). 
* The computer is very easy to beat in this release. This is because the AI is only partially finished. 